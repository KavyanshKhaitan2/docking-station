G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-06-05T19:36:22+05:30*
G04 #@! TF.ProjectId,daughterboard-left,64617567-6874-4657-9262-6f6172642d6c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-06-05 19:36:22*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.325000X-1.175000X0.325000X-1.175000X-0.325000X1.175000X-0.325000X1.175000X0.325000X0*%
%ADD11O,2.900000X1.200000*%
%ADD12RoundRect,0.250002X2.749998X-2.749998X2.749998X2.749998X-2.749998X2.749998X-2.749998X-2.749998X0*%
%ADD13C,6.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J8*
X46850000Y-43400000D03*
X46850000Y-45900000D03*
X46850000Y-47900000D03*
X46850000Y-50400000D03*
D11*
X43150000Y-40500000D03*
X43150000Y-53300000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J22*
X73300000Y-43200000D03*
D13*
X73300000Y-31200000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J6*
X46850000Y-59950000D03*
X46850000Y-62450000D03*
X46850000Y-64450000D03*
X46850000Y-66950000D03*
D11*
X43150000Y-57050000D03*
X43150000Y-69850000D03*
G04 #@! TD*
M02*
